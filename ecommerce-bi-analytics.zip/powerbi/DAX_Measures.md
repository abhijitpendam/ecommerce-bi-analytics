## DAX Measures

- Total Sales = SUM(Transactions[Amount])
