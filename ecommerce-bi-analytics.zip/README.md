# E-commerce BI & Analytics Project

End-to-end project using Power BI, SQL, Python, dbt, and AI.