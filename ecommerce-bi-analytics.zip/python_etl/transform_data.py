# Python script to clean and enrich e-commerce data
import pandas as pd
